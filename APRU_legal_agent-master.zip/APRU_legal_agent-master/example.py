"""
Example usage of the Legal LLM Agent
"""

import json
from legal_llm import analyze_contract, LegalAnalysisResult


def main():
    """Example usage"""
    
    # Sample contract text (in Russian/Thai legal context)
    sample_contract = """
    ДОГОВОР ОКАЗАНИЯ ФИНТЕХ-УСЛУГ
    
    1. СТОРОНЫ ДОГОВОРА
    Исполнитель: ООО "ФинТех Решения", зарегистрированная в Таиланде
    Заказчик: Физическое лицо, пользователь платформы
    
    2. ПРЕДМЕТ ДОГОВОРА
    Исполнитель обязуется предоставить цифровые финансовые услуги через мобильное приложение.
    
    3. СТОИМОСТЬ УСЛУГ
    Базовая стоимость: 1000 батов в месяц
    Комиссия за транзакции: 2% от суммы операции
    
    4. ПРАВА И ОБЯЗАННОСТИ СТОРОН
    4.1. Исполнитель имеет право в одностороннем порядке изменять тарифы и условия обслуживания.
    4.2. Заказчик обязан предоставить персональные данные для идентификации.
    
    5. ОТВЕТСТВЕННОСТЬ
    Исполнитель не несет ответственности за любые убытки, связанные с использованием услуг.
    
    6. РАСТОРЖЕНИЕ ДОГОВОРА
    Договор может быть расторгнут только по инициативе Исполнителя с уведомлением за 30 дней.
    
    7. ЗАЩИТА ДАННЫХ
    Персональные данные обрабатываются согласно внутренней политике компании.
    """
    
    try:
        print("Анализ договора с помощью Legal LLM (параллельная групповая обработка)...")
        print("=" * 60)
        
        # Analyze contract using grouped parallel processing
        # Note: You need to set GEMINI_API_KEY environment variable
        result: LegalAnalysisResult = analyze_contract(
            contract_text=sample_contract,
            contract_id="SAMPLE_001"
        )
        
        # Display results
        print(f"Дата анализа: {result.analysis_date}")
        print(f"Общий балл соответствия: {result.overall_compliance_score:.2f}")
        print(f"ID договора: {result.contract_id}")
        print()
        
        print("РЕЗЮМЕ:")
        print(result.summary)
        print()
        
        print("КРИТИЧЕСКИЕ ПРОБЛЕМЫ:")
        for issue in result.critical_issues:
            print(f"- {issue}")
        print()
        
        print("РЕКОМЕНДАЦИИ:")
        for recommendation in result.recommendations:
            print(f"- {recommendation}")
        print()
        
        # Show some key criteria analysis
        print("АНАЛИЗ КЛЮЧЕВЫХ КРИТЕРИЕВ:")
        print("-" * 40)
        
        criteria_to_show = [
            ("Односторонние изменения", result.unilateral_changes),
            ("Прозрачность условий", result.transparency_conditions),
            ("Распределение рисков", result.risk_distribution),
            ("Права на расторжение", result.termination_rights),
            ("Защита персональных данных", result.personal_data_protection),
        ]
        
        for name, criterion in criteria_to_show:
            print(f"\n{name}:")
            print(f"  Статус: {criterion.status.value}")
            print(f"  Объяснение: {criterion.explanation}")
            print(f"  Уверенность: {criterion.confidence_score:.2f}")
            if criterion.recommendations:
                print(f"  Рекомендации: {criterion.recommendations}")
        
        # Export to JSON
        result_json = result.model_dump_json(indent=2)
        with open("analysis_result.json", "w", encoding="utf-8") as f:
            f.write(result_json)
        print(f"\nПолный анализ сохранен в analysis_result.json")
        
    except Exception as e:
        print(f"Ошибка при анализе: {e}")
        print("\nУбедитесь, что:")
        print("1. Установлена переменная окружения GEMINI_API_KEY")
        print("2. Установлены все зависимости: pip install -r requirements.txt")
        print("3. Используется разделение на группы для обхода ограничений схемы Gemini")


if __name__ == "__main__":
    main()