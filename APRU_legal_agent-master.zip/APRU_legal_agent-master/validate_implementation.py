"""
Validation script to test Legal LLM implementation without API calls
"""

import json
from datetime import datetime
from legal_llm.models import (
    LegalAnalysisResult, 
    ComplianceStatus,
    UnilateralChanges,
    TransparencyConditions,
    RiskDistribution,
    TerminationRights,
    PartyResponsibility,
    GoodFaithInterpretation,
    LegalCompliance,
    RiskInformation,
    ComplaintMechanism,
    PartyIdentification,
    PersonalDataProtection,
    DataSubjectConsent,
    ContractLanguage,
    FullPriceIndication,
    ServiceDescription,
    TerminationRightInfo,
    OperatorRegistration,
    ServiceJurisdiction,
    LicensingRegistration,
    KYCQualification,
    AntiFraudMeasures,
    PaymentSystemCategory,
    ForeignCompanyStatus
)
from legal_llm.analyzer import _create_analysis_prompt


def create_mock_analysis_result() -> LegalAnalysisResult:
    """Create a mock analysis result for testing"""
    
    # Create sample data for each criterion
    sample_criterion_data = {
        "status": ComplianceStatus.PARTIALLY_COMPLIANT,
        "explanation": "Договор содержит некоторые проблемные условия, требующие доработки в соответствии с тайским законодательством.",
        "recommendations": "Рекомендуется пересмотреть условия для полного соответствия требованиям закона.",
        "confidence_score": 0.85
    }
    
    # Create all criteria instances
    criteria = {}
    criterion_classes = [
        UnilateralChanges, TransparencyConditions, RiskDistribution, TerminationRights,
        PartyResponsibility, GoodFaithInterpretation, LegalCompliance, RiskInformation,
        ComplaintMechanism, PartyIdentification, PersonalDataProtection, DataSubjectConsent,
        ContractLanguage, FullPriceIndication, ServiceDescription, TerminationRightInfo,
        OperatorRegistration, ServiceJurisdiction, LicensingRegistration, KYCQualification,
        AntiFraudMeasures, PaymentSystemCategory, ForeignCompanyStatus
    ]
    
    field_names = [
        "unilateral_changes", "transparency_conditions", "risk_distribution", "termination_rights",
        "party_responsibility", "good_faith_interpretation", "legal_compliance", "risk_information",
        "complaint_mechanism", "party_identification", "personal_data_protection", "data_subject_consent",
        "contract_language", "full_price_indication", "service_description", "termination_right_info",
        "operator_registration", "service_jurisdiction", "licensing_registration", "kyc_qualification",
        "anti_fraud_measures", "payment_system_category", "foreign_company_status"
    ]
    
    for criterion_class, field_name in zip(criterion_classes, field_names):
        criteria[field_name] = criterion_class(**sample_criterion_data)
    
    # Create complete analysis result
    result = LegalAnalysisResult(
        contract_id="TEST_CONTRACT_001",
        analysis_date=datetime.now().isoformat(),
        overall_compliance_score=0.72,
        summary="Договор требует доработки для полного соответствия тайскому законодательству. Обнаружено несколько критических проблем, связанных с защитой прав потребителей и обработкой персональных данных.",
        critical_issues=[
            "Отсутствие четких механизмов расторжения договора потребителем",
            "Недостаточная защита персональных данных",
            "Неясные условия ответственности сторон"
        ],
        recommendations=[
            "Добавить четкие процедуры расторжения договора в течение 7 дней",
            "Усилить меры защиты персональных данных согласно BE 2562",
            "Пересмотреть условия ответственности для обеспечения баланса прав сторон"
        ],
        **criteria
    )
    
    return result


def test_model_validation():
    """Test Pydantic model validation"""
    print("Testing Pydantic model validation...")
    
    try:
        result = create_mock_analysis_result()
        print(f"✓ Created LegalAnalysisResult with {len(result.critical_issues)} critical issues")
        print(f"✓ Overall compliance score: {result.overall_compliance_score}")
        print(f"✓ Contract ID: {result.contract_id}")
        return True
    except Exception as e:
        print(f"❌ Model validation failed: {e}")
        return False


def test_json_serialization():
    """Test JSON serialization"""
    print("\nTesting JSON serialization...")
    
    try:
        result = create_mock_analysis_result()
        json_data = result.model_dump_json(indent=2)
        
        # Verify it's valid JSON
        parsed = json.loads(json_data)
        print(f"✓ JSON serialization successful ({len(json_data)} chars)")
        print(f"✓ Contains {len(parsed)} top-level fields")
        return True
    except Exception as e:
        print(f"❌ JSON serialization failed: {e}")
        return False


def test_prompt_generation():
    """Test prompt generation"""
    print("\nTesting prompt generation...")
    
    try:
        sample_contract = "Тестовый договор об оказании финтех-услуг..."
        prompt = _create_analysis_prompt(sample_contract)
        
        # Check key elements in prompt
        checks = [
            ("Contract text included", sample_contract in prompt),
            ("Contains Russian criteria", "Отсутствие односторонних изменений" in prompt),
            ("Contains criteria instructions", "status:" in prompt),
            ("Contains all criteria", "Иностранный статус компании" in prompt),
        ]
        
        for check_name, check_result in checks:
            if check_result:
                print(f"✓ {check_name}")
            else:
                print(f"❌ {check_name}")
                return False
                
        print(f"✓ Prompt generated successfully ({len(prompt)} chars)")
        return True
    except Exception as e:
        print(f"❌ Prompt generation failed: {e}")
        return False


def test_compliance_statuses():
    """Test all compliance status values"""
    print("\nTesting compliance status enumeration...")
    
    try:
        statuses = ["compliant", "non_compliant", "partially_compliant", "unclear"]
        for status in statuses:
            cs = ComplianceStatus(status)
            print(f"✓ Status '{status}' -> {cs.value}")
        
        return True
    except Exception as e:
        print(f"❌ Compliance status test failed: {e}")
        return False


def main():
    """Run all validation tests"""
    print("Legal LLM Implementation Validation")
    print("=" * 50)
    
    tests = [
        test_model_validation,
        test_json_serialization,
        test_prompt_generation,
        test_compliance_statuses,
    ]
    
    results = []
    for test in tests:
        results.append(test())
    
    print("\n" + "=" * 50)
    print(f"Validation Results: {sum(results)}/{len(results)} tests passed")
    
    if all(results):
        print("🎉 All validation tests passed! The implementation is ready.")
        print("\nNext steps:")
        print("1. Set your GEMINI_API_KEY environment variable")
        print("2. Run: python example.py")
        print("3. Or use the analyze_contract() function in your code")
    else:
        print("❌ Some tests failed. Please review the implementation.")
        
    return all(results)


if __name__ == "__main__":
    success = main()
    exit(0 if success else 1)