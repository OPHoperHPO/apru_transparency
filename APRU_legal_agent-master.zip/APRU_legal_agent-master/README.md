# APRU Legal Agent

Legal contract analysis system using Google Gemini AI with **structured output** for compliance assessment based on Thai law.

## Overview

This system analyzes legal contracts (particularly fintech and digital services contracts) against 23 specific criteria from Thai law, including consumer protection laws, data protection regulations, and digital asset business requirements. 

**Now featuring Google Gemini's native structured output** for reliable, validated responses using Pydantic models.

## Features

- **🔥 NEW: Native Structured Output**: Uses Google Gemini's built-in structured output feature with Pydantic schemas
- **Reliable Data Validation**: Direct Pydantic model instantiation from Gemini responses
- **No JSON Parsing Required**: Native structured responses eliminate parsing errors
- **Google Gemini 2.5 Flash**: Latest model with enhanced capabilities
- **Thai Law Compliance**: Covers 23 key legal criteria based on Thai legislation
- **Confidence Scoring**: Each analysis includes confidence scores (0.0-1.0)
- **Comprehensive Coverage**: Analyzes everything from contract language to data protection

## Legal Criteria Covered

1. **Отсутствие односторонних изменений** - Unilateral changes prohibition
2. **Прозрачность и доступность условий** - Transparency and accessibility
3. **Справедливое распределение рисков** - Fair risk distribution
4. **Право на расторжение договора** - Contract termination rights
5. **Ответственность сторон** - Party responsibilities
6. **Добросовестность толкования договора** - Good faith interpretation
7. **Соответствие законодательству** - Legal compliance
8. **Информация о рисках** - Risk information disclosure
9. **Механизм подачи жалоб и рассмотрения исков** - Complaint mechanisms
10. **Идентификация сторон договора** - Party identification
11. **Защита персональных данных** - Personal data protection
12. **Согласие субъекта персональных данных** - Data subject consent
13. **Язык договора** - Contract language
14. **Указание полной цены** - Full price indication
15. **Подробное описание услуг** - Detailed service description
16. **Информация о праве расторжения договора** - Termination right information
17. **Регистрация оператора** - Operator registration
18. **Юрисдикция услуги** - Service jurisdiction
19. **Лицензирование и регистрация** - Licensing and registration
20. **Квалификация и проверка клиентов (KYC)** - KYC qualification
21. **Меры по борьбе с мошенничеством** - Anti-fraud measures
22. **Категория платежной системы** - Payment system category
23. **Иностранный статус компании** - Foreign company status

## Installation

1. Clone the repository:
```bash
git clone https://github.com/OPHoperHPO/APRU_legal_agent.git
cd APRU_legal_agent
```

2. Install dependencies:
```bash
pip install -r requirements.txt
```

3. Set up environment variables:
```bash
cp .env.example .env
# Edit .env and add your GEMINI_API_KEY
```

## Quick Start

```python
from legal_llm import analyze_contract

# Your contract text
contract_text = """
ДОГОВОР ОКАЗАНИЯ ФИНТЕХ-УСЛУГ
...
"""

# Analyze contract
result = analyze_contract(
    contract_text=contract_text,
    contract_id="CONTRACT_001"
)

# Access structured results
print(f"Overall compliance: {result.overall_compliance_score}")
print(f"Critical issues: {len(result.critical_issues)}")

# Check specific criteria
if result.unilateral_changes.status == "non_compliant":
    print(f"Issue with unilateral changes: {result.unilateral_changes.explanation}")
    
# Export to JSON
with open("analysis.json", "w", encoding="utf-8") as f:
    f.write(result.model_dump_json(indent=2, ensure_ascii=False))
```

## API Reference

### Main Function

```python
def analyze_contract(
    contract_text: str,
    api_key: Optional[str] = None,
    contract_id: Optional[str] = None,
    model_name: str = "gemini-2.5-flash"
) -> LegalAnalysisResult
```

**Parameters:**
- `contract_text`: The contract text to analyze
- `api_key`: Google Gemini API key (optional if set in environment)
- `contract_id`: Optional contract identifier
- `model_name`: Gemini model to use (default: "gemini-2.5-flash")

**Returns:** `LegalAnalysisResult` - Structured analysis result with all criteria (directly parsed from Gemini's structured output)

### Result Structure

```python
class LegalAnalysisResult(BaseModel):
    contract_id: Optional[str]
    analysis_date: str
    overall_compliance_score: float  # 0.0 to 1.0
    
    # All 23 legal criteria (structured objects)
    unilateral_changes: UnilateralChanges
    transparency_conditions: TransparencyConditions
    # ... (21 more criteria)
    
    summary: str
    critical_issues: list[str]
    recommendations: list[str]
```

Each criterion includes:
- `status`: "compliant", "non_compliant", "partially_compliant", or "unclear"
- `explanation`: Detailed analysis in Russian
- `confidence_score`: Float between 0.0 and 1.0
- `legal_reference`: Relevant Thai law reference
- `recommendations`: Optional improvement suggestions

## Configuration

Set these environment variables in your `.env` file:

```bash
# Required
GEMINI_API_KEY=your_api_key_here

# Optional
GEMINI_MODEL=gemini-2.5-flash
DEFAULT_TEMPERATURE=0.1
MAX_OUTPUT_TOKENS=8192
TOP_P=0.8
TOP_K=40
```

## 🆕 Structured Output Implementation

This implementation leverages Google Gemini's native structured output capabilities:

```python
# Configure Gemini for structured output
config = GenerateContentConfig(
    response_mime_type="application/json",
    response_schema=LegalAnalysisResult,  # Direct Pydantic model
    temperature=0.1
)

# Generate analysis with structured output
response = client.models.generate_content(
    model="gemini-2.5-flash",
    contents=prompt,
    config=config
)

# Get validated Pydantic object directly
result: LegalAnalysisResult = response.parsed
```

**Benefits:**
- ✅ **No JSON parsing errors** - Direct Pydantic validation
- ✅ **Type safety** - Full Python type hints and validation  
- ✅ **Reliability** - Gemini guarantees valid structure
- ✅ **Performance** - No manual parsing overhead
- ✅ **Developer Experience** - Auto-completion and error detection

## Example Usage

See `example.py` for a complete example:

```bash
python example.py
```

This will analyze a sample contract and save the results to `analysis_result.json`.

## Testing

Run the basic tests:

```bash
python test_legal_llm.py
```

Or with pytest (if installed):

```bash
pytest test_legal_llm.py -v
```

## Legal References

The system analyzes contracts based on:

- **Закон BE 2540** - Consumer protection laws
- **Гражданский кодекс Таиланда** - Thai Civil Code
- **Закон BE 2562 (2019)** - Personal Data Protection Act
- **Королевский указ BE 2568 (2025)** - Digital Asset Business Act
- **Закон BE 2560 (2017)** - Payment System Act
- **ISO 27001** - Information Security Standard

## Requirements

- Python 3.8+
- Google Gemini API key
- Internet connection for API calls

## License

[Add your license information here]

## Contributing

[Add contribution guidelines here]