"""
Basic tests for Legal LLM functionality with grouped analysis
"""

try:
    import pytest
    HAS_PYTEST = True
except ImportError:
    HAS_PYTEST = False
    # Mock pytest.raises for basic testing
    class MockPytest:
        @staticmethod
        def raises(exception_type):
            class RaisesContext:
                def __enter__(self):
                    return self
                def __exit__(self, exc_type, exc_val, exc_tb):
                    if exc_type is None:
                        raise AssertionError(f"Expected {exception_type.__name__} but no exception was raised")
                    return isinstance(exc_val, exception_type)
            return RaisesContext()
    pytest = MockPytest()

from unittest.mock import patch, MagicMock
from legal_llm.models import (
    LegalAnalysisResult, ComplianceStatus, UnilateralChanges,
    ConsumerProtectionAnalysis, LegalFrameworkAnalysis, DataProtectionAnalysis,
    ContractStructureAnalysis, RegulatoryComplianceAnalysis
)
from legal_llm.analyzer import (
    _create_consumer_protection_prompt,
    _create_legal_framework_prompt,
    _create_data_protection_prompt,
    _create_contract_structure_prompt,
    _create_regulatory_compliance_prompt,
    _calculate_overall_compliance,
    _create_summary
)


def test_create_grouped_prompts():
    """Test grouped prompt creation"""
    contract_text = "Test contract text"
    
    # Test all grouped prompts
    prompts = [
        _create_consumer_protection_prompt(contract_text),
        _create_legal_framework_prompt(contract_text),
        _create_data_protection_prompt(contract_text),
        _create_contract_structure_prompt(contract_text),
        _create_regulatory_compliance_prompt(contract_text)
    ]
    
    for prompt in prompts:
        assert contract_text in prompt
        assert "ТЕКСТ ДОГОВОРА:" in prompt
        assert "status:" in prompt
        assert "explanation:" in prompt
        assert "confidence_score:" in prompt


def test_grouped_analysis_models():
    """Test grouped analysis model validation"""
    from legal_llm.models import (
        TransparencyConditions, RiskDistribution, TerminationRights,
        PartyResponsibility, GoodFaithInterpretation, LegalCompliance,
        RiskInformation, ComplaintMechanism, PartyIdentification,
        PersonalDataProtection, DataSubjectConsent, ContractLanguage,
        FullPriceIndication, ServiceDescription, TerminationRightInfo,
        OperatorRegistration, ServiceJurisdiction, LicensingRegistration,
        KYCQualification, AntiFraudMeasures, PaymentSystemCategory,
        ForeignCompanyStatus
    )
    
    # Create sample criterion data
    criterion_data = {
        "status": ComplianceStatus.COMPLIANT,
        "explanation": "Test explanation",
        "confidence_score": 0.8
    }
    
    # Test Consumer Protection Analysis
    consumer_analysis = ConsumerProtectionAnalysis(
        unilateral_changes=UnilateralChanges(**criterion_data),
        transparency_conditions=TransparencyConditions(**criterion_data),
        risk_distribution=RiskDistribution(**criterion_data),
        termination_rights=TerminationRights(**criterion_data)
    )
    assert consumer_analysis.unilateral_changes.status == ComplianceStatus.COMPLIANT
    
    # Test Legal Framework Analysis
    legal_analysis = LegalFrameworkAnalysis(
        party_responsibility=PartyResponsibility(**criterion_data),
        good_faith_interpretation=GoodFaithInterpretation(**criterion_data),
        legal_compliance=LegalCompliance(**criterion_data),
        risk_information=RiskInformation(**criterion_data),
        complaint_mechanism=ComplaintMechanism(**criterion_data),
        party_identification=PartyIdentification(**criterion_data)
    )
    assert legal_analysis.legal_compliance.status == ComplianceStatus.COMPLIANT
    
    # Test Data Protection Analysis
    data_analysis = DataProtectionAnalysis(
        personal_data_protection=PersonalDataProtection(**criterion_data),
        data_subject_consent=DataSubjectConsent(**criterion_data)
    )
    assert data_analysis.personal_data_protection.status == ComplianceStatus.COMPLIANT
    
    # Test Contract Structure Analysis
    contract_analysis = ContractStructureAnalysis(
        contract_language=ContractLanguage(**criterion_data),
        full_price_indication=FullPriceIndication(**criterion_data),
        service_description=ServiceDescription(**criterion_data),
        termination_right_info=TerminationRightInfo(**criterion_data)
    )
    assert contract_analysis.contract_language.status == ComplianceStatus.COMPLIANT
    
    # Test Regulatory Compliance Analysis
    regulatory_analysis = RegulatoryComplianceAnalysis(
        operator_registration=OperatorRegistration(**criterion_data),
        service_jurisdiction=ServiceJurisdiction(**criterion_data),
        licensing_registration=LicensingRegistration(**criterion_data),
        kyc_qualification=KYCQualification(**criterion_data),
        anti_fraud_measures=AntiFraudMeasures(**criterion_data),
        payment_system_category=PaymentSystemCategory(**criterion_data),
        foreign_company_status=ForeignCompanyStatus(**criterion_data)
    )
    assert regulatory_analysis.operator_registration.status == ComplianceStatus.COMPLIANT


def test_overall_compliance_calculation():
    """Test overall compliance calculation from grouped results"""
    from legal_llm.models import (
        TransparencyConditions, RiskDistribution, TerminationRights,
        PartyResponsibility, GoodFaithInterpretation, LegalCompliance,
        RiskInformation, ComplaintMechanism, PartyIdentification,
        PersonalDataProtection, DataSubjectConsent, ContractLanguage,
        FullPriceIndication, ServiceDescription, TerminationRightInfo,
        OperatorRegistration, ServiceJurisdiction, LicensingRegistration,
        KYCQualification, AntiFraudMeasures, PaymentSystemCategory,
        ForeignCompanyStatus
    )
    
    # Create mixed compliance results
    compliant_data = {"status": ComplianceStatus.COMPLIANT, "explanation": "Good", "confidence_score": 0.9}
    non_compliant_data = {"status": ComplianceStatus.NON_COMPLIANT, "explanation": "Bad", "confidence_score": 0.8, "recommendations": "Fix this"}
    
    results = {
        'consumer_protection': ConsumerProtectionAnalysis(
            unilateral_changes=UnilateralChanges(**compliant_data),
            transparency_conditions=TransparencyConditions(**non_compliant_data),
            risk_distribution=RiskDistribution(**compliant_data),
            termination_rights=TerminationRights(**compliant_data)
        ),
        'legal_framework': LegalFrameworkAnalysis(
            party_responsibility=PartyResponsibility(**compliant_data),
            good_faith_interpretation=GoodFaithInterpretation(**compliant_data),
            legal_compliance=LegalCompliance(**compliant_data),
            risk_information=RiskInformation(**compliant_data),
            complaint_mechanism=ComplaintMechanism(**compliant_data),
            party_identification=PartyIdentification(**compliant_data)
        ),
        'data_protection': DataProtectionAnalysis(
            personal_data_protection=PersonalDataProtection(**compliant_data),
            data_subject_consent=DataSubjectConsent(**compliant_data)
        ),
        'contract_structure': ContractStructureAnalysis(
            contract_language=ContractLanguage(**compliant_data),
            full_price_indication=FullPriceIndication(**compliant_data),
            service_description=ServiceDescription(**compliant_data),
            termination_right_info=TerminationRightInfo(**compliant_data)
        ),
        'regulatory_compliance': RegulatoryComplianceAnalysis(
            operator_registration=OperatorRegistration(**compliant_data),
            service_jurisdiction=ServiceJurisdiction(**compliant_data),
            licensing_registration=LicensingRegistration(**compliant_data),
            kyc_qualification=KYCQualification(**compliant_data),
            anti_fraud_measures=AntiFraudMeasures(**compliant_data),
            payment_system_category=PaymentSystemCategory(**compliant_data),
            foreign_company_status=ForeignCompanyStatus(**compliant_data)
        )
    }
    
    overall_score, critical_issues, recommendations = _calculate_overall_compliance(results)
    
    # Should have high score with only 1 non-compliant out of 23 criteria
    assert 0.9 <= overall_score <= 1.0
    assert len(critical_issues) == 1
    assert len(recommendations) >= 1


def test_summary_creation():
    """Test summary creation"""
    # Create mock results dict
    results = {}  # Empty for this test
    overall_score = 0.75
    
    summary = _create_summary(results, overall_score)
    assert len(summary) > 50
    assert "соответствия" in summary
    assert "0.75" in summary


def test_legal_analysis_result_model():
    """Test LegalAnalysisResult model validation"""
    # Create a minimal valid result
    from datetime import datetime
    
    # Create all required criteria
    criteria_data = {
        "status": ComplianceStatus.COMPLIANT,
        "explanation": "Test explanation",
        "confidence_score": 0.8
    }
    
    result = LegalAnalysisResult(
        analysis_date=datetime.now().isoformat(),
        overall_compliance_score=0.75,
        unilateral_changes=UnilateralChanges(**criteria_data),
        transparency_conditions=_create_test_criterion("TransparencyConditions"),
        risk_distribution=_create_test_criterion("RiskDistribution"),
        termination_rights=_create_test_criterion("TerminationRights"),
        party_responsibility=_create_test_criterion("PartyResponsibility"),
        good_faith_interpretation=_create_test_criterion("GoodFaithInterpretation"),
        legal_compliance=_create_test_criterion("LegalCompliance"),
        risk_information=_create_test_criterion("RiskInformation"),
        complaint_mechanism=_create_test_criterion("ComplaintMechanism"),
        party_identification=_create_test_criterion("PartyIdentification"),
        personal_data_protection=_create_test_criterion("PersonalDataProtection"),
        data_subject_consent=_create_test_criterion("DataSubjectConsent"),
        contract_language=_create_test_criterion("ContractLanguage"),
        full_price_indication=_create_test_criterion("FullPriceIndication"),
        service_description=_create_test_criterion("ServiceDescription"),
        termination_right_info=_create_test_criterion("TerminationRightInfo"),
        operator_registration=_create_test_criterion("OperatorRegistration"),
        service_jurisdiction=_create_test_criterion("ServiceJurisdiction"),
        licensing_registration=_create_test_criterion("LicensingRegistration"),
        kyc_qualification=_create_test_criterion("KYCQualification"),
        anti_fraud_measures=_create_test_criterion("AntiFraudMeasures"),
        payment_system_category=_create_test_criterion("PaymentSystemCategory"),
        foreign_company_status=_create_test_criterion("ForeignCompanyStatus"),
        summary="Test summary",
        critical_issues=["Issue 1"],
        recommendations=["Recommendation 1"]
    )
    
    assert result.overall_compliance_score == 0.75
    assert len(result.critical_issues) == 1
    assert len(result.recommendations) == 1


def test_compliance_status_enum():
    """Test ComplianceStatus enum values"""
    assert ComplianceStatus.COMPLIANT == "compliant"
    assert ComplianceStatus.NON_COMPLIANT == "non_compliant"
    assert ComplianceStatus.PARTIALLY_COMPLIANT == "partially_compliant"
    assert ComplianceStatus.UNCLEAR == "unclear"


def test_unilateral_changes_model():
    """Test UnilateralChanges model"""
    criterion = UnilateralChanges(
        status=ComplianceStatus.COMPLIANT,
        explanation="Contract does not allow unilateral changes",
        confidence_score=0.9
    )
    
    assert criterion.status == ComplianceStatus.COMPLIANT
    assert "unilateral changes" in criterion.explanation.lower()
    assert criterion.confidence_score == 0.9
    assert criterion.recommendations is None


def _create_test_criterion(criterion_type: str):
    """Helper to create test criteria"""
    from legal_llm.models import (
        TransparencyConditions, RiskDistribution, TerminationRights, PartyResponsibility,
        GoodFaithInterpretation, LegalCompliance, RiskInformation, ComplaintMechanism,
        PartyIdentification, PersonalDataProtection, DataSubjectConsent, ContractLanguage,
        FullPriceIndication, ServiceDescription, TerminationRightInfo, OperatorRegistration,
        ServiceJurisdiction, LicensingRegistration, KYCQualification, AntiFraudMeasures,
        PaymentSystemCategory, ForeignCompanyStatus
    )
    
    criterion_classes = {
        "TransparencyConditions": TransparencyConditions,
        "RiskDistribution": RiskDistribution,
        "TerminationRights": TerminationRights,
        "PartyResponsibility": PartyResponsibility,
        "GoodFaithInterpretation": GoodFaithInterpretation,
        "LegalCompliance": LegalCompliance,
        "RiskInformation": RiskInformation,
        "ComplaintMechanism": ComplaintMechanism,
        "PartyIdentification": PartyIdentification,
        "PersonalDataProtection": PersonalDataProtection,
        "DataSubjectConsent": DataSubjectConsent,
        "ContractLanguage": ContractLanguage,
        "FullPriceIndication": FullPriceIndication,
        "ServiceDescription": ServiceDescription,
        "TerminationRightInfo": TerminationRightInfo,
        "OperatorRegistration": OperatorRegistration,
        "ServiceJurisdiction": ServiceJurisdiction,
        "LicensingRegistration": LicensingRegistration,
        "KYCQualification": KYCQualification,
        "AntiFraudMeasures": AntiFraudMeasures,
        "PaymentSystemCategory": PaymentSystemCategory,
        "ForeignCompanyStatus": ForeignCompanyStatus,
    }
    
    criterion_class = criterion_classes[criterion_type]
    return criterion_class(
        status=ComplianceStatus.COMPLIANT,
        explanation="Test explanation",
        confidence_score=0.8
    )


if __name__ == "__main__":
    # Run basic tests without pytest
    print("Running basic tests...")
    
    try:
        test_create_grouped_prompts()
        print("✓ test_create_grouped_prompts passed")
        
        test_grouped_analysis_models()
        print("✓ test_grouped_analysis_models passed")
        
        test_overall_compliance_calculation()
        print("✓ test_overall_compliance_calculation passed")
        
        test_summary_creation()
        print("✓ test_summary_creation passed")
        
        test_legal_analysis_result_model()
        print("✓ test_legal_analysis_result_model passed")
        
        test_compliance_status_enum()
        print("✓ test_compliance_status_enum passed")
        
        test_unilateral_changes_model()
        print("✓ test_unilateral_changes_model passed")
        
        print("\nAll tests passed! ✅")
        
    except Exception as e:
        print(f"❌ Test failed: {e}")
        import traceback
        traceback.print_exc()